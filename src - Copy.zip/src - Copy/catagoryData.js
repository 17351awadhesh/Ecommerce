const data = ["jewelery", "Electronics", "Men's Clothing", "Women's Clothing"]

export default data;