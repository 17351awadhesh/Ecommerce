const Sidebar = (props) => {
  const {selectedCategories, setSelectedCategories, data, setData, initialData} = props;
  let category = props.catagoryData.map((item, index) => {
    return (
      <li key={index}>
      <label>
        <input type="checkbox" onChange={e => {
          let updatedCategories=[]
          debugger
          if(e.target.checked){
            updatedCategories=[...selectedCategories,item?.toLowerCase()]
          }else{
            updatedCategories=selectedCategories.filter((x)=>x.toLowerCase()!==item.toLowerCase())
          }
        setSelectedCategories(updatedCategories)
        if(updatedCategories?.length)
          setData(initialData.filter((x)=>updatedCategories?.includes(x.category.toLowerCase())))
        else setData(initialData)
        }}  /> {item}
      </label>
    </li>
    )
});
console.log("chekbox", selectedCategories)
  return (
   
    <div className="sidebarWrapper relative">
      <p className="breadcrumb"><a href="#">Clothing</a> / <a href="#">Women’s</a> / Outerwear</p>
      <h3>Filter</h3>
      <h4>Categories</h4>
      <ul>
        {category}
      </ul>
    </div>
  );
};
export default Sidebar;
